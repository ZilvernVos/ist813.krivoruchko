package sut.ist813.krivoruchko.Example_KD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleKdApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleKdApplication.class, args);
	}

}
