package sut.ist813.krivoruchko.Example_KD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleKdApplicationTests {

	@Test
	void contextLoads() {
	}

}
